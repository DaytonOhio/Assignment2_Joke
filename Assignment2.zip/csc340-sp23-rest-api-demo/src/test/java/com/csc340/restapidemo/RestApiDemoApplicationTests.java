package com.csc340.restapidemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
